#include <iostream>

using namespace std;

void calcularIdade(int totalDias, int &anos, int &meses, int &dias) {
    anos = totalDias / 365;
    meses = (totalDias % 365) / 30;
    dias = (totalDias % 365) % 30;
}

int main() {
    int idadeEmDias, anos, meses, dias;

    cout << "Digite a idade em dias: ";
    cin >> idadeEmDias;

    calcularIdade(idadeEmDias, anos, meses, dias);

    cout << "Idade: " << anos << " anos, " << meses << " meses e " << dias << " dias." << endl;

    return 0;
}
