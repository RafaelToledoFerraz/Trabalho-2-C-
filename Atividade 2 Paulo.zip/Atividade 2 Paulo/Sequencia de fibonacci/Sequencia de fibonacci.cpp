#include <iostream>

using namespace std;

int fibonacciRecursivo(int n) {
    if (n <= 0) return -1;
    if (n == 1) return 0;
    if (n == 2) return 1;
    return fibonacciRecursivo(n - 1) + fibonacciRecursivo(n - 2);
}

int fibonacciIterativo(int n) {
    if (n <= 0) return -1;
    if (n == 1) return 0;
    if (n == 2) return 1;
    int a = 0, b = 1, c;
    for (int i = 3; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

int main() {
    int posicao;
    cout << "Digite a posicao desejada na sequencia de Fibonacci: ";
    cin >> posicao;

    int resultadoRecursivo = fibonacciRecursivo(posicao);
    int resultadoIterativo = fibonacciIterativo(posicao);

    if (resultadoRecursivo == -1 || resultadoIterativo == -1) {
        cout << "Erro: A posicao deve ser maior que zero." << endl;
    } else {
        cout << "Valor da sequencia de Fibonacci na posicao " << posicao << " (recursivo) = " << resultadoRecursivo << endl;
        cout << "Valor da sequencia de Fibonacci na posicao " << posicao << " (iterativo) = " << resultadoIterativo << endl;
    }

    return 0;
}
