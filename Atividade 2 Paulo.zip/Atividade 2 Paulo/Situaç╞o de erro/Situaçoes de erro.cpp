#include <iostream>

using namespace std;

int somaRecursiva(int n) {
    if (n <= 0) return -1;
    if (n == 1) return 1;
    return n + somaRecursiva(n - 1);
}

int somaIterativa(int n) {
    if (n <= 0) return -1;
    int soma = 0;
    for (int i = 1; i <= n; i++) {
        soma += i;
    }
    return soma;
}

int main() {
    int n;
    cout << "Digite um numero N: ";
    cin >> n;

    int resultadoRecursivo = somaRecursiva(n);
    int resultadoIterativo = somaIterativa(n);

    if (resultadoRecursivo == -1 || resultadoIterativo == -1) {
        cout << "Erro: N deve ser maior que zero." << endl;
    } else {
        cout << "Somatorio recursivo de 1 a " << n << " = " << resultadoRecursivo << endl;
        cout << "Somatorio iterativo de 1 a " << n << " = " << resultadoIterativo << endl;
    }

    return 0;
}
