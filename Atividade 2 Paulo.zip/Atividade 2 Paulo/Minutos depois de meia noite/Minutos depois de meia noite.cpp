#include <iostream>

using namespace std;

void converterMinutos(int totalMinutos, int &hora, int &minuto) {
    hora = totalMinutos / 60;
    minuto = totalMinutos % 60;
}

int main() {
    int minutosPassados, hora, minuto;

    cout << "Digite o total de minutos passados desde a meia-noite: ";
    cin >> minutosPassados;

    converterMinutos(minutosPassados, hora, minuto);

    cout << "Hora atual: " << hora << " horas e " << minuto << " minutos." << endl;

    return 0;
}
