#include <iostream>

using namespace std;

const int numMaxM = 20;
const int numMaxN = 25;

void lerMatriz(int matriz[numMaxM][numMaxN], int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cout << "Digite o elemento [" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
        }
    }
}

void transporMatriz(int matriz[numMaxM][numMaxN], int transposta[numMaxN][numMaxM], int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            transposta[j][i] = matriz[i][j];
        }
    }
}

void multiplicarPorK(int matriz[numMaxM][numMaxN], int resultado[numMaxM][numMaxN], int m, int n, int k) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            resultado[i][j] = matriz[i][j] * k;
        }
    }
}

void adicionarMatrizes(int matriz1[numMaxM][numMaxN], int matriz2[numMaxM][numMaxN], int resultado[numMaxM][numMaxN], int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j];
        }
    }
}

void imprimirMatriz(int matriz[numMaxM][numMaxN], int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int m, n;
    int matriz1[numMaxM][numMaxN], matriz2[numMaxM][numMaxN], transposta[numMaxN][numMaxM];
    int matrizMultiplicada[numMaxM][numMaxN], matrizAdicionada[numMaxM][numMaxN];
    int k;

    cout << "Digite o numero de linhas (M) da matriz (M<=20): ";
    cin >> m;
    cout << "Digite o numero de colunas (N) da matriz (N<=25): ";
    cin >> n;

    if (m <= 0 || m > numMaxM || n <= 0 || n > numMaxN) {
        cout << "Erro: M e N devem estar dentro dos limites especificados (M <= 20, N <= 25) e serem maiores que zero." << endl;
        return 1;
    }

    cout << "Digite os elementos da matriz 1:" << endl;
    lerMatriz(matriz1, m, n);

    cout << "Digite o valor de K para multiplicacao: ";
    cin >> k;

    transporMatriz(matriz1, transposta, m, n);
    multiplicarPorK(matriz1, matrizMultiplicada, m, n, k);

    cout << "Digite os elementos da matriz 2 para adicao:" << endl;
    lerMatriz(matriz2, m, n);
    adicionarMatrizes(matriz1, matriz2, matrizAdicionada, m, n);

    cout << "Matriz transposta:" << endl;
    imprimirMatriz(transposta, n, m);

    cout << "Matriz multiplicada por " << k << ":" << endl;
    imprimirMatriz(matrizMultiplicada, m, n);

    cout << "Resultado da adicao das matrizes:" << endl;
    imprimirMatriz(matrizAdicionada, m, n);

    return 0;
}
